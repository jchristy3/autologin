SETUP

1. Download and install Python 3.6.5
2. Download chromedriver_win32.zip, extract (right-click, Extract All...), move chromedriver.exe to this folder
3. Run CreateAutoTasks.bat (if it doesn't work, schedule restrSign.bat to run with Task Scheduler)
4. edit restrSign.bat such that your username and password immediately follow %YOURPATH%\autologin.py, separated by spaces

